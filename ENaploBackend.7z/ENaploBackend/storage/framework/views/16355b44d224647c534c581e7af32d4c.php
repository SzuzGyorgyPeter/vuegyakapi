<!doctype html>
<html lang="hu">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>ENAPLO</title>
</head>
<body>

<h1>Osztályzatok</h1>

<hr>

<ul>
    <?php $__currentLoopData = $grades; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $grade): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <li>
            <?php echo e($grade->grade); ?> (x<?php echo e($grade->weight); ?>) [<?php echo e($grade->comment); ?>]

            <ul>
                <li><?php echo e($grade->student->name); ?></li>
            </ul>

        </li>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</ul>

</body>
</html>
<?php /**PATH C:\xampp\htdocs\ENaploBackend\resources\views/grades.blade.php ENDPATH**/ ?>